# Locatial

Locatial is a place-first publishing system.

## Repo structure

- `harness/` — product truth: PRDs, schema, skills, decisions, Codex instructions
- `apps/` — future application code
- `packages/` — shared UI, map, and TypeScript packages
- `prototypes/` — disposable prototypes and experiments
- `archive/` — old or superseded material

## Mental model

**Library = what you have**  
**Projects = what you make**  
**Published = what people see**

## Start here

1. `harness/00_start_here/MASTER_INDEX.md`
2. `harness/08_codex/CODEX_README.md`
3. `harness/06_decisions/DECISION_LOG.md`
