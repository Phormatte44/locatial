# Locatial Harness — Master Index

This harness is the source of truth for Locatial.

## Core truth

Library = what you have.  
Projects = what you make.  
Published = what people see.

## Product spine

- Library
- Place Nodes
- Project Creation
- Editor Screen
- Story Stops
- Stop Editor
- Research Tray
- Spatial Context
- Datasets & Layers
- Preview
- Publish & Maintenance

## Read order for Codex

1. `harness/00_start_here/LOCATIAL_CANONICAL_TRUTHS.md`
2. `harness/01_product_thesis/PRODUCT_THESIS.md`
3. `harness/02_prds/PRD_INDEX.md`
4. Relevant PRD
5. Relevant skill file
6. `harness/03_schema/DOMAIN_MODEL.md`
7. `harness/06_decisions/DECISION_LOG.md`

## Rule

Do not build from memory. Read the harness first.
