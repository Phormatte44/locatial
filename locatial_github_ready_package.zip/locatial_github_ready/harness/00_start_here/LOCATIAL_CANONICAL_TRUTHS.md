# Locatial Canonical Truths

These are the highest-authority product truths.

1. Library is what the creator has.
2. Projects are what the creator makes.
3. Published is what the audience sees.
4. A Place Node is created once and referenced many times.
5. Place truth and project meaning are separate.
6. A Story Stop may reference a Place Node, but it does not require one.
7. Datasets live in Library.
8. Dataset features are not automatically Places.
9. Dataset features can become visual layers, Place Nodes, both, or neither.
10. The map is a spatial lens, not the editor.
11. Preview is part of authoring, not just final QA.
12. AI may assist, but the creator remains accountable.
13. Do not create separate editors for Story, Guide, and Collection.
14. Do not build a full GIS, social network, marketplace, or freeform page builder until explicitly adopted.
