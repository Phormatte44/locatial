export type ProjectType = "story" | "guide" | "collection";

export type PlaceAssignmentState = "unassigned" | "candidate" | "assigned";

export type StopStatus =
  | "empty"
  | "outlined"
  | "researching"
  | "drafting"
  | "review"
  | "done";
