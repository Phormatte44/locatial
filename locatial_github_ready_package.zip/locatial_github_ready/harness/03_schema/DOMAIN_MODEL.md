# Domain Model

## Main objects

- Library Item
- Capture
- Place Node
- Dataset
- Dataset Feature
- Layer
- Project
- Project Item / Stop
- Content Block
- Publication

## Separation

Place Node stores reusable spatial truth.  
Project Item / Stop stores project-specific meaning.
