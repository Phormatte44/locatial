# Decision Log

## Template

### YYYY-MM-DD — Decision title

**Status:** Adopted / Prototype / Validate / Deferred / Killed  
**Decision:**  
**Why:**  
**Affected PRDs:**  
**Affected skills:**  
**What would reverse this:**  

---

### 2026-06-15 — Library / Projects / Published model

**Status:** Adopted  
**Decision:** Use Library = what you have, Projects = what you make, Published = what people see.  
**Why:** Simple mental model that avoids exposing internal ontology too early.  
**Affected PRDs:** Library, Project Creation, Publish  
**Affected skills:** Global Rules, Product Architecture  
**What would reverse this:** Real users fail to understand where captures/datasets live.

---

### 2026-06-15 — Dataset lives in Library

**Status:** Adopted  
**Decision:** Datasets are uploaded and managed at Library level, then referenced by Projects.  
**Why:** Prevents one-off project imports and supports reuse across stories/guides/collections.  
**Affected PRDs:** Library, Dataset Layer, Project Creation  
**Affected skills:** Dataset Import  
**What would reverse this:** Users only ever use datasets once and find Library-based import confusing.
