# Skill — Product Architecture

Use this when touching domain model, routes, app structure, or data persistence.

## Key objects
- Library Item
- Capture
- Place Node
- Dataset
- Dataset Feature
- Layer
- Project
- Stop / Project Item
- Content Block
- Publication

## Anti-drift rules
- Do not clone Place data into Stops.
- Do not create separate project models for Story, Guide, and Collection.
- Do not let dataset features automatically become Places.
- Do not hide the difference between reusable truth and local meaning.
