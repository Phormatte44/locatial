# Skill — Map / Spatial Context

Use this for location assignment, map preview, quick markup, and stop-level spatial validation.

## States
- Unassigned
- Candidate
- Assigned

## Optimize for
- Fast place assignment
- Clear missing-location warnings
- Relevant layers
- Lightweight markup
- Map as support, not authoring center
