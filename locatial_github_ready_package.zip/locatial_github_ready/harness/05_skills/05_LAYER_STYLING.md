# Skill — Dataset Layer Styling

Use this when rendering datasets visually.

## Standard
Style layers, not individual features by default.

## Required styling concepts
- Single color
- Color by category
- Color by numeric value
- Size by numeric value
- Point shape
- Line style
- Polygon fill/border/opacity
- Label field
- Presets

## Do not
- Require users to understand GeoJSON
- Make manual per-feature styling the default
- Build a full cartography suite before the core loop works
