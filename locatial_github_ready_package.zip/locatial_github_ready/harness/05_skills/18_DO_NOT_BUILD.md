# Skill — Do Not Build

Do not build unless explicitly adopted:

- Social feed
- Comments
- Followers
- Marketplace
- Payments
- Full GIS
- Advanced cartography suite
- Freeform page builder
- Custom template builder
- Conversational AI copilot
- Separate Story / Guide / Collection editors
- 3D globe inside the Creator Studio
- Complex collaboration
- Advanced analytics
