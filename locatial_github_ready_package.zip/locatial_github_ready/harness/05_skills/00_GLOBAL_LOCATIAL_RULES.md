# Skill — Global Locatial Rules

Load this for every task.

## Must preserve
- Library = what you have
- Projects = what you make
- Published = what people see
- Place truth and project meaning are separate
- Map is a lens, not the editor
- Datasets live in Library

## Do not
- Invent new top-level objects without approval
- Build separate editors for Story, Guide, and Collection
- Turn the editor into GIS
- Turn the product into a social network
- Build a full freeform page builder
