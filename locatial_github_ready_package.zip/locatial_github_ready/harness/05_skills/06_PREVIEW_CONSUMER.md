# Skill — Preview / Consumer Experience

Use this when building preview or published audience views.

## Optimize for
- Phone-first reading
- Map synchronized to story progression
- Place detail access
- Route and layer comprehension
- Jump back to edit

## Do not
- Use fake preview data
- Make preview only a final QA step
- Let published output diverge from editor data
