# Skill — Dataset Import

Use this for CSV, XLSX, GeoJSON, GPX, KML, JSON, APIs, and Google Sheets.

## Model
Dataset → Features / Rows → Layers → optional Place Nodes → Projects

## Must do
- Import into Library first
- Parse fields
- Preview data
- Let user decide meaning
- Support visual layer, Place candidates, route, reference data, or both

## Do not
- Assume one feature equals one Place
- Build only for F1 circuits
- Dump huge files directly into a project
- Expose raw GeoJSON as primary UI
