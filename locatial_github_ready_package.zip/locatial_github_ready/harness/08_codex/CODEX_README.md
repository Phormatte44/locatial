# Codex README

Codex should treat this harness as source of truth.

## Always read first

1. `harness/00_start_here/LOCATIAL_CANONICAL_TRUTHS.md`
2. `CHANGELOG.md`
3. `harness/06_decisions/DECISION_LOG.md`

## Then read

4. Relevant PRD
5. Relevant skill file
6. Relevant schema file

## Rules

- Do not invent features outside the PRDs.
- Preserve Library / Projects / Published.
- Preserve Place Node reuse.
- Preserve Dataset → Features/Rows → Layers → optional Place Nodes → Projects.
- Do not let the map become the editor.
- Update the decision log when making architectural choices.
- If implementation diverges from a PRD, document why.
