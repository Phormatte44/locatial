# PRD — Publish & Maintenance

## Purpose
Publishing creates a live artifact and a maintenance obligation.

## Required functionality
- Slug
- Visibility
- Disclosure
- Publish checks
- Missing location warnings
- Low-confidence warnings
- Stale place warnings
- Closed place handling
- Unpublished changes
- Republish
- Update Place once and propagate everywhere
