# PRD Index

## Core PRDs

1. `core_workflows/01_LIBRARY_PRD.md`
2. `core_workflows/02_PLACE_NODE_PRD.md`
3. `core_workflows/03_PROJECT_CREATION_PRD.md`
4. `editor_screen/04_EDITOR_SCREEN_PRD.md`
5. `editor_screen/04A_STORY_STOPS_PRD.md`
6. `editor_screen/04B_STOP_EDITOR_PRD.md`
7. `editor_screen/04C_RESEARCH_TRAY_PRD.md`
8. `spatial_data/05_SPATIAL_CONTEXT_PRD.md`
9. `spatial_data/06_DATASET_LAYER_PRD.md`
10. `core_workflows/07_PREVIEW_PRD.md`
11. `core_workflows/08_PUBLISH_MAINTENANCE_PRD.md`

## Current highest-priority PRDs

1. Editor Screen
2. Library
3. Place Node
4. Dataset & Layer
5. Preview
