# PRD — Spatial Context

## Purpose
Spatial Context handles location assignment and lightweight map validation for a selected stop.

## Required functionality
- Search location
- Assign Place Node
- Keep stop unassigned
- Candidate location state
- Map preview
- Show referenced layers
- Add quick markup
- Open full Dataset / Layer workspace when needed

## Principle
Location assignment should be powerful but should not dominate writing.
