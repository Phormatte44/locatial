# Design Principles

- Editorial before technical
- Calm, precise, premium
- Content-led
- Map as lens, not center
- Strong typography
- Minimal controls
- Progressive disclosure
- One controlled accent
- Avoid dashboard clutter
