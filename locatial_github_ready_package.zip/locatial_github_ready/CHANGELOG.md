# Changelog

Use this file to tell Codex what recently changed.

## 2026-06-15 — Initial GitHub harness

Created GitHub-ready Locatial harness structure.

## How to update

Each adopted change should include:

- Date
- What changed
- Why
- Affected PRDs
- Affected skills
- Status: adopted / prototype / validate / deferred / killed
